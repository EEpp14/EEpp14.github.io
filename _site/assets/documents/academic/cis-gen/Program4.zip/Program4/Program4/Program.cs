﻿// Program 4
// CIS 199-50-4228
// Due: 12/2/2022
// By: F2212

// creates an array from derived class objects and uses a display method to print our ToString method from our product class for each item in our array
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program4
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                // Create product objects
                Product product1 = new Product("PepsiCo", "Gatorade", 675134, "Beverage", 3.50, true);
                Product product2 = new Product("PepsiCo", "Pepsi", 675135, "Beverage", 3.00, true);
                Product product3 = new Product("PepsiCo", "Dr Pepper", 675136, "Beverage", 3.00, true);
                Product product4 = new Product("PepsiCo", "Sierra Mist", 675137, "Beverage", 3.00, true);
                Product product5 = new Product("PepsiCo", "Brisk", 675136, "Beverage", 4.00, true);

                // Create an array of products
                Product[] products = { product1, product2, product3, product4, product5 };

                // Display products
                WriteLine("List of Products We Sell");
                WriteLine("------------------------");
                DisplayProducts(products);
            }
            catch (Exception ex)
            {
                WriteLine($"An error occurred: {ex.Message}");
            }
        }

        public static void DisplayProducts(Product[] products)
        {
            foreach (Product currentProduct in products)
            {
                WriteLine(currentProduct);
            }
        }
    }
}

